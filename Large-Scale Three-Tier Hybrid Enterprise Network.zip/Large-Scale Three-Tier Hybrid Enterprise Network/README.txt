Project: Large-Scale Three-Tier Hybrid Enterprise Network
Author: Ahmed Alsaedi
Description: Comprehensive Enterprise Network Architecture featuring a Spine-Leaf Data Center design, OSPFv2 routing, HSRP redundancy, VLAN segmentation, localized DHCP server implementation, and Extended ACLs for secure Data Center traffic enforcement.